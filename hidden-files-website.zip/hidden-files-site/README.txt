THE HIDDEN FILES — WEBSITE DEPLOYMENT

Your website is ready to publish. To get a public HTTPS link for free using GitHub Pages:

1. Sign in to https://github.com/ or create a free account.
2. Create a new PUBLIC repository named hidden-files (or any name you prefer).
3. Upload index.html from this folder to the repository's top level (not inside another folder).
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose the main branch and / (root), then Save.
7. Wait for GitHub Pages to publish. Your URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/hidden-files/
8. In Settings → Pages, enable Enforce HTTPS if the option is shown.

Note: Replace YOUR-GITHUB-USERNAME with your GitHub username. GitHub creates the actual public URL; it cannot be reserved or activated until you publish the repository.

The page is explicitly labeled as a fictional educational/media-literacy project and states the established historical finding that American Airlines Flight 77 struck the Pentagon.
